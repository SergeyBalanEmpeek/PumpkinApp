﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using System.Linq;
using Warehouse;
namespace WarehouseTest
{
    [TestClass]
    public class UnitTest1
    {
        #region Product Tests
        [TestMethod]
        public void ProductNotExistsTest()
        {
            Storage storage = new Storage();

            PrivateObject privateObject = new PrivateObject(storage);
            List<Product> productsList = privateObject.Invoke("GetProducts") as List<Product>;

            //By default no products are expected
            Assert.AreEqual(0, productsList.Count);         
        }

        [TestMethod]
        public void ProductExistTest()
        {
            Storage storage = new Storage();
            storage.BuyPumpkin(new Account("Client A"), 10);

            PrivateObject privateObject = new PrivateObject(storage);
            List<Product> productsList = privateObject.Invoke("GetProducts") as List<Product>;

            //1 product should be exists - Pumpkin
            Assert.AreEqual(1, productsList.Count);        
        }
        #endregion

        #region One User Tests
        [TestMethod]
        public void OrderOneUserTest1()
        {
            Storage storage = new Storage();
            storage.BuyPumpkin(new Account("Client A"), 10);

            List<Product> productsList = new PrivateObject(storage).Invoke("GetProducts") as List<Product>;
            Product product = productsList.FirstOrDefault();
            List<Order> ordersList = product.GetOrders();

            Assert.AreEqual(1, ordersList.Count);
        }
        #endregion

        #region Two Users Test
        [TestMethod]
        public void OrdersTwoUsersTest1()
        {
            Storage storage = new Storage();
            storage.BuyPumpkin(new Account("Client A"), 10);
            storage.BuyPumpkin(new Account("Client B"), 10);

            List<Product> productsList = new PrivateObject(storage).Invoke("GetProducts") as List<Product>;
            Product product = productsList.FirstOrDefault();
            List<Order> ordersList = product.GetOrders();

            Assert.AreEqual(2, ordersList.Count);
        }

        [TestMethod]
        public void OrdersTwoUsersTest2()
        {
            Storage storage = new Storage();
            storage.BuyPumpkin(new Account("Client A"), 10);
            storage.SellPumpkin(new Account("Client B"), 10);

            List<Product> productsList = new PrivateObject(storage).Invoke("GetProducts") as List<Product>;
            Product product = productsList.FirstOrDefault();
            List<Order> ordersList = product.GetOrders();

            Assert.AreEqual(0, ordersList.Count);
        }

        [TestMethod]
        public void OrdersTwoUsersTest3()
        {
            Storage storage = new Storage();
            storage.SellPumpkin(new Account("Client A"), 10);
            storage.BuyPumpkin(new Account("Client B"), 10);

            List<Product> productsList = new PrivateObject(storage).Invoke("GetProducts") as List<Product>;
            Product product = productsList.FirstOrDefault();
            List<Order> ordersList = product.GetOrders();

            Assert.AreEqual(0, ordersList.Count);
        }

        [TestMethod]
        public void OrdersTwoUsersTest4()
        {
            Storage storage = new Storage();
            storage.SellPumpkin(new Account("Client A"), 10);
            storage.BuyPumpkin(new Account("Client B"), 9);

            List<Product> productsList = new PrivateObject(storage).Invoke("GetProducts") as List<Product>;
            Product product = productsList.FirstOrDefault();
            List<Order> ordersList = product.GetOrders();

            Assert.AreEqual(2, ordersList.Count);
        }

        [TestMethod]
        public void OrdersTwoUsersTest5()
        {
            Storage storage = new Storage();
            storage.SellPumpkin(new Account("Client A"), 9);
            storage.BuyPumpkin(new Account("Client B"), 10);

            List<Product> productsList = new PrivateObject(storage).Invoke("GetProducts") as List<Product>;
            Product product = productsList.FirstOrDefault();
            List<Order> ordersList = product.GetOrders();

            Assert.AreEqual(0, ordersList.Count);
        }
        #endregion

    }
}
