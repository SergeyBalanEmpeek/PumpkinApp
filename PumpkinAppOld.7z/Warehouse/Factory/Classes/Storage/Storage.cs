﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Warehouse
{
    /// <summary>
    /// A basic Storage, where we can store and sell products
    /// </summary>
    public class Storage
    {
        private List<Product> products = new List<Product>();

        /// <summary>
        /// Buy an item
        /// </summary>
        /// <param name="account">User who want to make a purchase</param>
        /// <param name="product">Product name</param>
        /// <param name="price">Desired price to purchase an item</param>
        public void Buy(Account account, Product product, decimal price)
        {
            //Console.WriteLine($"{account.Name} wants to buy  {product.Name} for {price}$ in {Name}");
            Operation(account, product, OperationType.Buy, price);
        }

        /// <summary>
        /// Sell an item
        /// </summary>
        /// <param name="account">User who want to make a sell</param>
        /// <param name="product">Product name</param>
        /// <param name="price">Desired price to sell an item</param>
        public void Sell(Account account, Product product, decimal price)
        {
            //Console.WriteLine($"{account.Name} wants to sell {product.Name} for {price}$ in {Name}");
            Operation(account, product, OperationType.Sell, price);
        }

        /// <summary>
        /// Buy a Pumpkin
        /// </summary>
        /// <param name="account">User who want to make a purchase</param>
        /// <param name="price">Desired price to purchase an item</param>
        public void BuyPumpkin(Account account, decimal price)
        {
            //Console.WriteLine($"{account.Name} wants to buy  {product.Name} for {price}$ in {Name}");
            Operation(account, new Pumpkin(), OperationType.Buy, price);
        }

        /// <summary>
        /// Sell a Pumpkin
        /// </summary>
        /// <param name="account">User who want to make a sell</param>
        /// <param name="price">Desired price to sell an item</param>
        public void SellPumpkin(Account account,  decimal price)
        {
            //Console.WriteLine($"{account.Name} wants to sell {product.Name} for {price}$ in {Name}");
            Operation(account, new Pumpkin(), OperationType.Sell, price);
        }

        /// <summary>
        /// Do some operation with an item
        /// </summary>
        /// <param name="account">User who want to make a sell</param>
        /// <param name="product">Product name</param>
        /// <param name="type">Operation type</param>
        /// <param name="price">Desired price to sell an item</param>
        private void Operation(Account account, Product product, OperationType type, decimal price)
        {
            //find existing product
            Product existingProduct = products.Where(c => c.GetType() == product.GetType()).FirstOrDefault();
            if (existingProduct == null)
            {
                existingProduct = product;
                products.Add(product);
            }

            //Do required operation according to type
            switch(type)
            {
                case OperationType.Buy:
                    existingProduct.Buy(account, price);
                    break;

                case OperationType.Sell:
                    existingProduct.Sell(account, price);
                    break;

                default:
                    throw (new Exception($"Operation {type} is not supported"));
            }
        }

        /// <summary>
        /// Storage name
        /// </summary>
        public virtual string Name
        {
            get
            {
                return "Unknown Storage";
            }
        }

        /// <summary>
        /// This method is using for unit testing only
        /// </summary>
        /// <returns></returns>
        private List<Product> GetProducts()
        {
            return products;
        }
    }
}
