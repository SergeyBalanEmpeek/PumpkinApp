﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Warehouse
{
    /// <summary>
    /// Product that could be sold
    /// </summary>
    public class Product: IPurchasable
    {
        /// <summary>
        /// Current pending orders
        /// </summary>
        private List<Order> pendingOrders = new List<Order>();

        /// <summary>
        /// Buy item
        /// </summary>
        /// <param name="account">user who want to make a purchase</param>
        /// <param name="price">desired price to purchase an item</param>
        public void Buy(Account account,decimal price)
        {
            ProcessOrder(new Order(account, OperationType.Buy, price));
        }

        /// <summary>
        /// Sell item
        /// </summary>
        /// <param name="account">user who want to make a sell</param>
        /// <param name="price">desired price to sell an item</param>
        public void Sell(Account account, decimal price)
        {
            ProcessOrder(new Order(account, OperationType.Sell, price));
        }

        /// <summary>
        /// Product name
        /// </summary>
        public virtual string Name
        {
            get
            {
                return "Unknown Product";
            }
        }

        /// <summary>
        /// Process new order
        /// </summary>
        /// <param name="newOrder">New Order</param>
        private void ProcessOrder(Order newOrder)
        {
            lock (pendingOrders)            //Locking orders list to resolve multi-thread issues
            {
                //Prepare order list according to rules
                List<Order> orders = pendingOrders.Where(c => c.Type != newOrder.Type).ToList();                //Remove orders with same type

                if (newOrder.Type == OperationType.Buy)
                    orders = orders.OrderBy(c => c.Price).ThenBy(c => c.Date).ToList();                  //Lowest price should be first
                else
                    orders = orders.OrderByDescending(c => c.Price).ThenBy(c => c.Date).ToList();        //Highest price should be first


                foreach (var pendingOrder in orders)
                {

                    if (newOrder.Type == OperationType.Buy && newOrder.Price >= pendingOrder.Price)
                    {
                        //Sell a product for a price, offered by a purchaser
                        Console.WriteLine($"{newOrder.Account.Name} bought {Name} from {pendingOrder.Account.Name} for {newOrder.Price}$");
                        pendingOrders.Remove(pendingOrder);
                        return;
                    }

                    if (newOrder.Type == OperationType.Sell && pendingOrder.Price >= newOrder.Price)
                    {
                        //Sell a product for a price, offered by a seller
                        Console.WriteLine($"{newOrder.Account.Name} sold {Name} to {pendingOrder.Account.Name} for {newOrder.Price}$");
                        pendingOrders.Remove(pendingOrder);
                        return;
                    }
                }

                //if we are here, we were unable to satisfy this order. Put it to query
                pendingOrders.Add(newOrder);
            }
        }


        /// <summary>
        /// Get list of orders
        /// </summary>
        /// <returns></returns>
        internal List<Order> GetOrders()
        {
            return pendingOrders;
        }
    }
}
