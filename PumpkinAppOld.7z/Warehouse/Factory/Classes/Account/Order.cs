﻿using System;
using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("WarehouseTest")]     //make Order be visible for testing
namespace Warehouse
{
    /// <summary>
    /// Order, made by account
    /// </summary>
    internal class Order
    {
        /// <summary>
        /// Account, who made an order
        /// </summary>
        public Account Account { get; private set; }

        /// <summary>
        /// Action type
        /// </summary>
        public OperationType Type { get; private set; }

        /// <summary>
        /// Desired price of deal
        /// </summary>
        public decimal Price { get; private set; }

        /// <summary>
        /// Action register date
        /// </summary>
        public DateTime Date { get; private set; }


        /// <summary>
        /// Create a new order
        /// </summary>
        /// <param name="account">Account, who made an order</param>
        /// <param name="type">Operation type</param>
        /// <param name="price">Desired price</param>
        public Order(Account account, OperationType type, decimal price)
        {
            Account = account;
            Type = type;
            Price = price;
            Date = DateTime.UtcNow;
        }

    }
}
