﻿using System;

namespace Warehouse
{
    /// <summary>
    /// Purchasable Item
    /// </summary>
    interface IPurchasable
    {
        /// <summary>
        /// Buy item
        /// </summary>
        /// <param name="account">user who want to make a purchase</param>
        /// <param name="price">desired price to purchase an item</param>
        void Buy(Account account, decimal price);

        /// <summary>
        /// Sell item
        /// </summary>
        /// <param name="account">user who want to make a sell</param>
        /// <param name="price">desired price to sell an item</param>
        void Sell(Account account, decimal price);
    }
}
