﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Warehouse;

namespace PumpkinApp
{
    class Program
    {
        static void Main(string[] args)
        {
            //Create storage instance
            MainStorage storage = new MainStorage();
            
            //Process user orders
            storage.BuyPumpkin(new Account("Client A"), 10);
            storage.BuyPumpkin(new Account("Client B"), 11);
            storage.SellPumpkin(new Account("Client C"), 15);
            storage.SellPumpkin(new Account("Client D"), 9);
            storage.BuyPumpkin(new Account("Client E"), 10);
            storage.SellPumpkin(new Account("Client F"), 10);
            storage.BuyPumpkin(new Account("Client G"), 100);

            Console.ReadLine();
        }
    }
}
