﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Warehouse
{
    /// <summary>
    /// Operation Type
    /// </summary>
    internal enum OperationType
    {
        /// <summary>
        /// Purchasing Operation
        /// </summary>
        Buy = 0,

        /// <summary>
        /// Selling Operation
        /// </summary>
        Sell = 1,
    }
}
