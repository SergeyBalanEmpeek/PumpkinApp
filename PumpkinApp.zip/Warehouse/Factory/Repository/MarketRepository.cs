﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("WarehouseTest")]     //make Order be visible for testing
namespace Warehouse
{
    class MarketRepository
    {
        /// <summary>
        /// List of all orders
        /// </summary>
        List<Order> Orders { get; } = new List<Order>();

        /// <summary>
        /// Register order
        /// </summary>
        /// <param name="account">User who want to make a sell</param>
        /// <param name="product">Product name</param>
        /// <param name="type">Operation type</param>
        /// <param name="price">Desired price to sell an item</param>
        public void RegisterOrder(Account account, Product product, OperationType type, decimal price)
        {
            Order newOrder = new Order(account, product, type, price);

            lock (Orders)            //Locking orders list to resolve multi-thread issues
            {
                IEnumerable<Order> filteredOrders = Orders.Where(c => c.Type != newOrder.Type);             //Remove orders with same type

                if (newOrder.Type == OperationType.Buy)
                {
                    //Purchasing operation

                    //Lowest price should be first
                    filteredOrders = filteredOrders.OrderBy(c => c.Price).ThenBy(c => c.Date);             

                    //Find any purchasable order 
                    Order deal = filteredOrders.Where(c => newOrder.Price >= c.Price).FirstOrDefault();    
                    if (deal != null)
                    {
                        Console.WriteLine($"{newOrder.Account.Name} bought {product.Name} from {deal.Account.Name} for {newOrder.Price}$");

                        //Remove this deal from order list since it's completed now
                        Orders.Remove(deal);
                        return;
                    }
                }
                else
                {
                    //Selling operation

                    //Highest price should be first
                    filteredOrders = filteredOrders.OrderByDescending(c => c.Price).ThenBy(c => c.Date);

                    //Find any purchasable order 
                    Order deal = filteredOrders.Where(c => c.Price >= newOrder.Price).FirstOrDefault();
                    if (deal != null)
                    {
                        Console.WriteLine($"{newOrder.Account.Name} sold {product.Name} to {deal.Account.Name} for {newOrder.Price}$");

                        //Remove this deal from order list since it's completed now
                        Orders.Remove(deal);
                        return;
                    }
                }

                //if we are here, we were unable to satisfy this order. Put it to query
                Orders.Add(newOrder);
            }
        }  
    }
}
