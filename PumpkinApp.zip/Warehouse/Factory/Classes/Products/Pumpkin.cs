﻿using System;

namespace Warehouse
{
    /// <summary>
    /// A Pumpkin product
    /// </summary>
    public class Pumpkin: Product
    {
        /// <summary>
        /// Product name
        /// </summary>
        public override string Name
        {
            get
            {
                return "a Pumpkin";
            }
        }
    }
}
