﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Warehouse
{
    /// <summary>
    /// Product that could be sold
    /// </summary>
    public abstract class Product
    {
        /// <summary>
        /// Product name
        /// </summary>
        public virtual string Name
        {
            get
            {
                return "Unknown Product";
            }
        }
    }
}
