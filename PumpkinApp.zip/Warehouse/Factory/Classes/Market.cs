﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Warehouse
{
    /// <summary>
    /// A market, where we can store and sell products
    /// </summary>
    public class Market
    {
        MarketRepository repository = new MarketRepository();

        #region Generic Add/Sell methods
        /// <summary>
        /// Buy an item
        /// </summary>
        /// <param name="account">User who want to make a purchase</param>
        /// <param name="product">Product name</param>
        /// <param name="price">Desired price to purchase an item</param>
        public void Buy(Account account, Product product, decimal price)
        {
            //Console.WriteLine($"{account.Name} wants to buy  {product.Name} for {price}$ in {Name}");
            repository.RegisterOrder(account, product, OperationType.Buy, price);
        }

        /// <summary>
        /// Sell an item
        /// </summary>
        /// <param name="account">User who want to make a sell</param>
        /// <param name="product">Product name</param>
        /// <param name="price">Desired price to sell an item</param>
        public void Sell(Account account, Product product, decimal price)
        {
            //Console.WriteLine($"{account.Name} wants to sell {product.Name} for {price}$ in {Name}");
            repository.RegisterOrder(account, product, OperationType.Sell, price);
        }
        #endregion

        #region Pumpkin related methods
        /// <summary>
        /// Buy a Pumpkin
        /// </summary>
        /// <param name="account">User who want to make a purchase</param>
        /// <param name="price">Desired price to purchase an item</param>
        public void BuyPumpkin(Account account, decimal price)
        {
            //Console.WriteLine($"{account.Name} wants to buy  {product.Name} for {price}$ in {Name}");
            repository.RegisterOrder(account, new Pumpkin(), OperationType.Buy, price);
        }

        /// <summary>
        /// Sell a Pumpkin
        /// </summary>
        /// <param name="account">User who want to make a sell</param>
        /// <param name="price">Desired price to sell an item</param>
        public void SellPumpkin(Account account,  decimal price)
        {
            //Console.WriteLine($"{account.Name} wants to sell {product.Name} for {price}$ in {Name}");
            repository.RegisterOrder(account, new Pumpkin(), OperationType.Sell, price);
        }
        #endregion
    }
}
